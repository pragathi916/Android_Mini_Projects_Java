package com.example.batterylife;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    TextView t;
    ConstraintLayout ly;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
       t=findViewById(R.id.tv);
       ly=findViewById(R.id.ly);
       BatteryBroadcast b=new BatteryBroadcast();
       registerReceiver(b,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
    }

    public class BatteryBroadcast extends BroadcastReceiver{
        @Override
        public void onReceive(Context context, Intent intent) {
            int percent=intent.getIntExtra("level",0);
            t.setText("Battery level:"+percent);
            if(percent>=60)
                ly.setBackgroundColor(Color.GREEN);
            else if(percent>=20)
                ly.setBackgroundColor(Color.YELLOW);
            else
                ly.setBackgroundColor(Color.RED);
        }
    }


}