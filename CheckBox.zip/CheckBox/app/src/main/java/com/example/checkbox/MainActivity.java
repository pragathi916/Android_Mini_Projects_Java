package com.example.checkbox;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    CheckBox c1;
    CheckBox c2;
    CheckBox c3;
    CheckBox c4;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        c1=findViewById(R.id.burger);
        c2=findViewById(R.id.pizza);
        c3=findViewById(R.id.noodles);
        c4=findViewById(R.id.pasta);
        b1=findViewById(R.id.menu);

       b1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               String li=" ";
               int amt=0;
               if(c1.isChecked()) {
                   li = li + c1.getText().toString() + "\n";
                   amt=amt+100;
               }
               if(c2.isChecked()) {
                   li = li + c2.getText().toString() + "\n";
                   amt=amt+199;
               }
               if(c3.isChecked()) {
                   li = li + c3.getText().toString() + "\n";
                   amt=amt+80;
               }
               if(c4.isChecked()) {
                   li = li + c4.getText().toString() + "\n";
                   amt=amt+140;
               }

               Toast.makeText(MainActivity.this,li, Toast.LENGTH_SHORT).show();
               Toast.makeText(MainActivity.this,amt, Toast.LENGTH_SHORT).show();
           }
       });


    }
}