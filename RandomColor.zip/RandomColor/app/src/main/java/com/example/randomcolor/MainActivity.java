package com.example.randomcolor;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    Button b;
    ConstraintLayout ly;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        b=findViewById(R.id.rc);
        ly=findViewById(R.id.bg);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Random rn=new Random();
                int r=rn.nextInt(256);
                int g=rn.nextInt(256);
                int b=rn.nextInt(256);
                ly.setBackgroundColor(Color.rgb(r,g,b));
            }
        });
    }
}