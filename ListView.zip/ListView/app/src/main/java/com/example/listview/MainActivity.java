package com.example.listview;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    EditText st;
    Button b;
    ListView lv;
    ArrayList<String> arr=new ArrayList<>();
    ArrayAdapter<String> adp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        st=findViewById(R.id.name);
        b=findViewById(R.id.add);
        lv=findViewById(R.id.list);
        arr.add("ABC");
        arr.add("DEF");
        adp=new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1,arr);
        lv.setAdapter(adp);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s=st.getText().toString();
                if (!s.equals("")& !arr.contains(s)){
                    arr.add(s);
                    adp.notifyDataSetChanged();
                }
            }
        });
        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                arr.remove(i);
                adp.notifyDataSetChanged();
                return false;
            }
        });
    }

}