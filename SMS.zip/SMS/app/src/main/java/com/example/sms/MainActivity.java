package com.example.sms;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button b;
    EditText m,ph;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        b=findViewById(R.id.send);
        ph=findViewById(R.id.phno);
        m=findViewById(R.id.msg);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s= m.getText().toString();
                String p=ph.getText().toString();
              SmsManager sms=SmsManager.getDefault();
              sms.sendTextMessage(p,null,s,null,null);
                Toast.makeText(MainActivity.this, "Message Sent", Toast.LENGTH_SHORT).show();

            }
        });
    }
}