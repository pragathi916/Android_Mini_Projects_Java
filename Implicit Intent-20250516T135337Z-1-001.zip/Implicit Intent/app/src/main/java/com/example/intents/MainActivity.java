package com.example.intents;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button c,b,m;

    EditText p,u,l;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        p=findViewById(R.id.Phno);
        u=findViewById(R.id.url);
        l=findViewById(R.id.Map);
        c=findViewById(R.id.call);
        b=findViewById(R.id.browse);
        m=findViewById(R.id.maps);
    c.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            String ph=p.getText().toString();
            Intent i=new Intent(Intent.ACTION_CALL, Uri.parse("tel:"+ph));
            startActivity(i);
        }
    });

b.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        String web=u.getText().toString();
        Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(web));
        startActivity(i);
    }
});
m.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View view) {
        String loc=l.getText().toString();
        Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse("google.navigation:q="+loc));
        startActivity(i);
    }
});
    }

}