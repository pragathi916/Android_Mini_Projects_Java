package com.example.database;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button ins,sel;
    EditText name,usn,age;
    DataBaseClass db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        name=findViewById(R.id.name);
        usn=findViewById(R.id.usn);
        age=findViewById(R.id.age);
        ins=findViewById(R.id.ins);
        sel=findViewById(R.id.sel);
        db=new DataBaseClass(MainActivity.this,"STUDENTDATA",null,1);
        ins.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                long val = db.insertData(name.getText().toString(), usn.getText().toString(), Integer.parseInt(age.getText().toString()));
                if (val == -1)
                    Toast.makeText(MainActivity.this, "Insertion Failed", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity.this, "Insertion successful", Toast.LENGTH_SHORT).show();
            }
        });
        sel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor c=db.selectData(usn.getText().toString());
                if(c.getCount()==0)
                    Toast.makeText(MainActivity.this, "No student data", Toast.LENGTH_SHORT).show();
                else {
                    c.moveToFirst();
                    String n1=c.getString(0);
                    String u1=c.getString(1);
                    int a1=c.getInt(2);
                    String data="Name:"+n1+"\nusn:"+u1+"\nage:"+a1;
                    Toast.makeText(MainActivity.this, data, Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

}