package com.example.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataBaseClass extends SQLiteOpenHelper {

    public DataBaseClass(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE STUDENT(Name varchar(20),usn char(10) primary key,age int)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
    public long insertData(String name,String usn,int age)
    {
        SQLiteDatabase db=getWritableDatabase();
        ContentValues c=new ContentValues();
        c.put("Name",name);
        c.put("usn",usn);
        c.put("age",age);
        return db.insert("STUDENT",null,c);

    }
    public Cursor selectData(String u){
        SQLiteDatabase db=getWritableDatabase();
        return db.rawQuery("SELECT * FROM STUDENT where usn='"+u+"'",null);
    }

}
