package com.example.explicitintent;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class secondactivity extends AppCompatActivity {
    Button b2;
    EditText e2;
    TextView t2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_secondactivity);
        b2 = findViewById(R.id.send2);
        t2 = findViewById(R.id.resp2);
        e2 = findViewById(R.id.msg2);

        Intent i1 = getIntent();
        String s2 = i1.getStringExtra("message1");
        t2.setText(s2);

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s3 = e2.getText().toString();
                Intent i = new Intent();
                i.putExtra("message2", s3);
                setResult(RESULT_OK, i);
                finish();
            }
        });
    }


}